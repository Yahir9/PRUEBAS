// Genera el addon estático (protocolo Stremio, compatible con Nuvio) en docs/
// Requiere: Node 20+, variable de entorno TMDB_API_KEY (clave v3 de TMDB).
import { mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';

const KEY = process.env.TMDB_API_KEY;
const BASE = process.env.TMDB_BASE || 'https://api.themoviedb.org/3';
const LANG = process.env.TMDB_LANG || 'es-MX';
const PAGES = Number(process.env.TMDB_PAGES || 10); // 20 títulos por página
const PAGE_SIZE = 100;
const OUT = 'docs';
const CACHE = 'data/ids.json';
if (!KEY) { console.error('Falta TMDB_API_KEY'); process.exit(1); }

const day = (offset) => new Date(Date.now() + offset * 864e5).toISOString().slice(0, 10);
const anime = { with_genres: '16', with_original_language: 'ja' };

const CATALOGS = [
  { type: 'series', id: 'anime-popular', name: 'Anime popular', kind: 'tv',
    params: { ...anime, sort_by: 'popularity.desc' } },
  { type: 'series', id: 'anime-emision', name: 'Anime en emisión', kind: 'tv',
    params: { ...anime, sort_by: 'popularity.desc', 'air_date.gte': day(-7), 'air_date.lte': day(7) } },
  { type: 'series', id: 'anime-mejor-valorado', name: 'Anime mejor valorado', kind: 'tv',
    params: { ...anime, sort_by: 'vote_average.desc', 'vote_count.gte': '300' } },
  { type: 'movie', id: 'anime-peliculas', name: 'Películas de anime', kind: 'movie',
    params: { ...anime, sort_by: 'popularity.desc' } },
];

async function tmdb(route, params = {}) {
  const url = new URL(BASE + route);
  url.search = new URLSearchParams({ api_key: KEY, language: LANG, ...params });
  for (let attempt = 1; ; attempt++) {
    const res = await fetch(url);
    if (res.ok) return res.json();
    if ((res.status === 429 || res.status >= 500) && attempt < 5) {
      await new Promise((r) => setTimeout(r, 1500 * attempt));
      continue;
    }
    throw new Error(`TMDB ${res.status} en ${route}`);
  }
}

async function pool(items, size, fn) {
  const out = new Array(items.length);
  let i = 0;
  await Promise.all(Array.from({ length: size }, async () => {
    while (i < items.length) { const n = i++; out[n] = await fn(items[n]); }
  }));
  return out;
}

let cache = {};
try { cache = JSON.parse(await readFile(CACHE, 'utf8')); } catch {}

async function imdbId(kind, id) {
  const k = `${kind}:${id}`;
  if (!(k in cache)) cache[k] = (await tmdb(`/${kind}/${id}/external_ids`)).imdb_id || null;
  return cache[k];
}

const img = (p, size) => (p ? `https://image.tmdb.org/t/p/${size}${p}` : undefined);

async function build(cat) {
  const results = [];
  for (let page = 1; page <= PAGES; page++) {
    const data = await tmdb(`/discover/${cat.kind}`, { ...cat.params, page: String(page) });
    results.push(...data.results);
    if (page >= data.total_pages) break;
  }
  const metas = await pool(results, 8, async (r) => {
    const imdb = await imdbId(cat.kind, r.id);
    if (!imdb) return null; // sin ID de IMDb la app no puede mostrar la ficha
    const date = r.first_air_date || r.release_date || '';
    return {
      id: imdb, type: cat.type, name: r.name || r.title,
      poster: img(r.poster_path, 'w500'), background: img(r.backdrop_path, 'w1280'),
      description: r.overview || undefined,
      releaseInfo: date.slice(0, 4) || undefined,
      imdbRating: r.vote_average ? r.vote_average.toFixed(1) : undefined,
    };
  });
  const seen = new Set();
  return metas.filter((m) => m && !seen.has(m.id) && seen.add(m.id));
}

// 1) Descargar todo primero: si algo falla, no se toca lo publicado.
const built = [];
for (const cat of CATALOGS) {
  const metas = await build(cat);
  if (!metas.length) throw new Error(`Catálogo vacío: ${cat.id}`);
  built.push({ cat, metas });
  console.log(`${cat.id}: ${metas.length} títulos`);
}

// 2) Escribir archivos.
await rm(path.join(OUT, 'catalog'), { recursive: true, force: true });
const json = (file, obj) => mkdir(path.dirname(file), { recursive: true })
  .then(() => writeFile(file, JSON.stringify(obj)));

for (const { cat, metas } of built) {
  const dir = path.join(OUT, 'catalog', cat.type);
  await json(path.join(dir, `${cat.id}.json`), { metas: metas.slice(0, PAGE_SIZE) });
  for (let skip = PAGE_SIZE; skip < metas.length; skip += PAGE_SIZE)
    await json(path.join(dir, cat.id, `skip=${skip}.json`), { metas: metas.slice(skip, skip + PAGE_SIZE) });
  // página final vacía para que la app sepa que ya no hay más
  const end = Math.ceil(metas.length / PAGE_SIZE) * PAGE_SIZE;
  await json(path.join(dir, cat.id, `skip=${end}.json`), { metas: [] });
}

await json(path.join(OUT, 'manifest.json'), {
  id: 'community.anime.tmdb.diario',
  version: '1.0.0',
  name: 'Anime Diario (TMDB)',
  description: 'Catálogos de anime generados con TMDB y actualizados cada día con GitHub Actions.',
  resources: ['catalog'],
  types: ['series', 'movie'],
  idPrefixes: ['tt'],
  catalogs: CATALOGS.map((c) => ({ type: c.type, id: c.id, name: c.name, extra: [{ name: 'skip' }] })),
  behaviorHints: { configurable: false },
});
await json(CACHE, cache);
console.log('Listo.');
