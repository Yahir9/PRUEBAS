# Anime Diario (TMDB) — addon para Nuvio

Addon estático de catálogos de anime (protocolo Stremio, compatible con Nuvio).
GitHub Actions lo regenera cada día con datos de TMDB y GitHub Pages lo publica.

## Instalación (una sola vez)

1. Crea un repositorio **público** en GitHub y sube todo el contenido de esta carpeta
   (incluida la carpeta oculta `.github`).
2. **Clave de TMDB:** en el repositorio ve a *Settings → Secrets and variables → Actions →
   New repository secret*. Nombre: `TMDB_API_KEY`. Valor: tu clave de API v3 de TMDB.
3. **Primera ejecución:** pestaña *Actions → Actualizar catálogo → Run workflow*.
   Al terminar aparecerán `docs/manifest.json` y `docs/catalog/`.
4. **GitHub Pages:** *Settings → Pages → Source: Deploy from a branch → Branch: `main`,
   carpeta `/docs` → Save*.
5. **En Nuvio:** *Settings → Addons → Add Addon* y pega
   `https://TU_USUARIO.github.io/TU_REPO/manifest.json`.

Desde entonces se actualiza solo todos los días a las 04:17 a. m. (hora de Ciudad de México).

## Ajustes

- **Hora:** línea `cron` en `.github/workflows/update.yml` (está en UTC; México = UTC-6).
- **Catálogos:** lista `CATALOGS` en `scripts/update.mjs`.
- **Cantidad de títulos:** variable `TMDB_PAGES` (20 títulos por página, 10 por defecto).

## Notas

- Si TMDB falla, el workflow termina con error, conserva el catálogo anterior y GitHub te avisa por correo.
- Los títulos sin ID de IMDb se omiten, porque la app usa ese ID para mostrar la ficha y los episodios.
- GitHub pausa los workflows programados tras 60 días sin actividad en el repositorio;
  los commits diarios del propio addon lo mantienen activo.
